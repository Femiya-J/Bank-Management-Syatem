# Banking-management-system-
I developed a web-based Banking Management System using HTML, CSS, MySQL, Servlet, and JDBC. It includes customer and admin pages. Customers can create accounts, log in securely, update profiles, view account details, and perform transactions. Admins can review daily transactions
